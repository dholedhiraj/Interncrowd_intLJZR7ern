# Host-a-Dynamic-website

![0cb3e9e2-3bfc-4bb8-aeaa-ae51541c87ae](https://user-images.githubusercontent.com/84792579/215271714-22097b08-a09e-4b7d-b7af-64109997e25e.jpg)


![7708a8d1-9ef2-43e6-936d-c76c47c5d260](https://user-images.githubusercontent.com/84792579/215271705-2874e20b-e602-4b92-825e-ad186c418e0a.jpg)


![e877033c-f463-4aea-bd02-2089c24438a4](https://user-images.githubusercontent.com/84792579/215271770-2172e16d-be3b-4453-9b36-644b1d0b48ba.jpg)


![5487a4d7-2bd8-4638-8381-c7ab457b757f](https://user-images.githubusercontent.com/84792579/215271778-392ad6b3-5043-4ff2-9173-5cf3fd0687bf.jpg)
